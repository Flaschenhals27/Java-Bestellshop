
package java_bestellshop;
import java.io.FileOutputStream;
import java.io.IOException;

public class Bestellung {
    Kunde kunde;
    Produkt produkt;
    int menge;
    
    public Bestellung(Kunde kunde, Produkt produkt, int menge) throws ZuVielBestelltException {
        this.kunde = kunde;
        this.produkt = produkt;
        if (menge > this.produkt.getLagerbestand()) {
            throw new ZuVielBestelltException("Zu viel Bestellt!");
        }
        this.menge = menge;
    }
    
    public void export() {
        try (FileOutputStream fos = new FileOutputStream("C:\\Users\\noobs\\Documents\\NetBeansKlausur\\bestellung.txt", true)) {
            String output = ("-Kundendaten-\n" +"Name/Vorname: " +kunde.getName() +" "+ kunde.getVorname() +"\nPLZ:  "+kunde.getPLZ() + "\nTelefon: " + kunde.getTelefonnummer() + "\nhat bestellt");
            fos.write(output.getBytes());
        } catch (IOException e) {
            System.out.print("Keine Übertragung möglich!");
        }
    }
    
    public int getProduktLagerbestand() {
        return produkt.lagerbestand;
    }
    public Kunde getKunde() {
        return this.kunde;
    }
    public Produkt getProdukt() {
        return this.produkt;
    }
    public int getMenge() {
        return this.menge;
    }
}
