
package java_bestellshop;

public interface Lieferung {
}
