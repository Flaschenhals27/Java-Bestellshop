
package java_bestellshop;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
public class Java_Bestellshop {

    ArrayList<Produkt> katalog = new ArrayList();

    public static void main(String[] args){
        Scanner scan = new Scanner(System.in);
        Java_Bestellshop obj = new Java_Bestellshop();
        obj.initShop();
        obj.printProducts(obj.buildProducts());
        System.out.println("Willkommen im Java-Shop");
        System.out.println("-----------------------");
        System.out.println("Schauen Sie zum bestellen gerne in den Katalog");
        System.out.println("Möchten Sie etwas kaufen? (Enter: k)");
        String eingabe = scan.nextLine();
        if (eingabe.charAt(0) != 'k' && !eingabe.equals("kaufen") && !eingabe.equals("ja")) {
            System.out.println("Schauen Sie gerne wieder vorbei!\n");
            System.exit(0);
        }
        obj.erstelleBestellung();
    }
    
    public void initShop() {
        katalog.add(new Elektronik(2,"Iphone 15",849,11));
        katalog.add(new Elektronik(2,"Iphone 15",769,11));
        katalog.add(new Elektronik(2,"Lenovo Thinkpad",1099,3));
        katalog.add(new Elektronik(3,"Bosch Spülmaschine",599,6));
        katalog.add(new Buch("978-3596190539","Dale Carnegie","Wie man Freunde gewinnt",12,4));
        katalog.add(new Buch("978-3440168646","Werner E. Celnik","Astronomie für Einsteiger",20,2));
        katalog.add(new Buch("978-3451360008","Jesus","Die Bibel",666,9));
        katalog.add(new Kleidung('S',"Baumwolle","Gucci T-Shirt",349,1));
        katalog.add(new Kleidung('M',"Baumwolle","Teddy T-Shirt",2,4));
    }
    
    private String buildProducts() {
        StringBuilder str = new StringBuilder();        
        str.append("<----------Bücher---------->\n");
        for (Produkt p : katalog) {
            if (p instanceof Buch) {
                str.append(p.getObjectDetails()+"\n");
            }
        }            
        str.append("<----------Elektronik---------->\n");
        for (Produkt p : katalog) {
            if (p instanceof Elektronik) {
                str.append(p.getObjectDetails()+"\n");
            }
        }           
        str.append("<----------Kleidung---------->\n");
        for (Produkt p : katalog) {
            if (p instanceof Kleidung) {
                str.append(p.getObjectDetails()+"\n");
            }
        }
        return str.toString();
    }
    
    public void printProducts(String argument) {
        try (FileOutputStream fos = new FileOutputStream("C:\\Users\\noobs\\Documents\\NetBeansKlausur\\bestellung.txt", false)) {
            fos.write(argument.getBytes());
        } catch (IOException e) {
            System.out.print("Keine Übertragung möglich!");
        }
    }
    
    public void erstelleBestellung(){
        Scanner scan = new Scanner(System.in);
        Kunde k = erstelleKunde();
        Produkt p=null;
        do {
            try {
                p = getAuftrag();
            } catch(FalschesProduktException e){
                System.out.println("--------------------\nDas gewünschte Produkt existiert nicht.\nEs erfolgt eine erneute Abfrage des Produktnamens\n--------------------");
            }
        } while(p==null);
        
        int anzahl=0;
        Bestellung bestellung=null;
        do {
            try {
                System.out.print("Anzahl Exemplare: ");
                anzahl = scan.nextInt();        
                bestellung = new Bestellung(k,p,anzahl);
            } catch(ZuVielBestelltException e) {
                System.out.println("-------------------\nSie haben zuviel bestellt, geben Sie eine Bestellmenge von maximal " + p.getLagerbestand() + " an\n-------------------");
            }
        } while(p.getLagerbestand() < anzahl);
        p.setLagerbestand(p.getLagerbestand()-anzahl);
        printBestellung(bestellung);
    }
    
    private void printBestellung(Bestellung b) {
        System.out.println("----------Bestellung----------");
        System.out.println("Kundenname: " + b.getKunde().getName().toUpperCase() + " " + b.getKunde().getVorname().toUpperCase());
        System.out.println("Produkt: "+ b.getProdukt().getName());
        System.out.println("Menge: " + b.getMenge());
        System.out.println("--------------------------------\n");
        printProducts(buildProducts());
    }
    
    private Kunde erstelleKunde() {
        Scanner scan = new Scanner(System.in);
        System.out.println("Wie lautet dein Vorname?");
        String vorname = scan.next();
        System.out.println("Wie lautet dein Nachname?");
        String name = scan.next();
        System.out.println("Wie lautet deine PLZ?");
        int PLZ = scan.nextInt();
        System.out.println("Wie lautet deine Telefonnummer?");
        int tel = scan.nextInt();
        Kunde k = new Kunde(name,vorname,tel,PLZ);
        return k;
    }
    
    private Produkt getAuftrag() throws FalschesProduktException {
        Scanner scan = new Scanner(System.in);
        System.out.print("Name des Produktes: ");
        String name = scan.nextLine();
        ArrayList<Produkt> treffer = new ArrayList();
        for (Produkt p : katalog) {
            if (p.matches(name)) {
                treffer.add(p);
            }
        }
        if (treffer.isEmpty()) {
            throw new FalschesProduktException("");
        } else if (treffer.size() >= 2) {
            return specifyArticle(treffer);
        } else return treffer.get(0);
    }
    
    private Produkt specifyArticle(ArrayList<Produkt> treffer) {
        Scanner scan = new Scanner(System.in);
        int i=1;
        String name = treffer.get(0).getName();
        for (Produkt p : katalog) {
            if (p.matches(name)) {
                p.setId(i);
                i++;
            }
        }
        System.out.println("Es wurden mehrere Produkte mit dem selben Namen gefunden, welcher Artikel ist gemeint?");
        printSpecifiedArticle();
        System.out.print("Artikelnummer: ");
        int nr = scan.nextInt();
        for (Produkt p : katalog) {
            if (p.getId() == nr) {
                return p;
            }
        }
        return null;
    }
    
    private void printSpecifiedArticle() {
        StringBuilder str = new StringBuilder();
        for (Produkt p : katalog) {
            if (p.getId() != 0) {
                str.append("Nr: " + p.getId() + " | " + p.getObjectDetails()+"\n");
            }
        }
        printProducts(str.toString());
    }
}

class AuftragsException extends Exception { //Package sichtbarkeit
    public AuftragsException(String Nachricht) {
        super(Nachricht);
    }
}
class FalschesProduktException extends AuftragsException {
    public FalschesProduktException(String Nachricht) {
        super(Nachricht);
    }
}
class ZuVielBestelltException extends AuftragsException {
    public ZuVielBestelltException(String Nachricht) {
        super(Nachricht);
    }
}
/*
Changelogs v3.2:
-getter und setter konsequent eingesetzt
-ignorieren von leerzeichen und großkleinschreibung
-sicherstellen das gewünschtes produkt existiert mithilfe Exception-Kartoffel
-Lagerbestand-Klasse in Java_Bestellshop integriert
-Exceptions aufgeteilt -> .class Dateien gespart
-Abfrage zum kaufen intuitiver gemacht
-Überbestellung verhindert
-Ausgabe etwas verbessert
*/
/*
Aufgaben für v4.0:
-Ankauffunktion
-Artikel mit Lagerbestand=0 löschen
-Eingaben abdichten
-Mehrere Bestellungen auf einmal tätigen
-Preis + Lieferkosten berechnen, Gewicht als Member
-...
*/


